module USTGlobal_Flipkart {
}