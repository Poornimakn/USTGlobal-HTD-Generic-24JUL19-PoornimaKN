package com.dev.phone;

import java.util.HashMap;
import java.util.Scanner;

public class PhoneSimulator extends Data{

	public static HashMap<String, Data> hm= new HashMap<String,Data>();
	public static PhoneSimulator ph=new PhoneSimulator();
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Press 1 to Show All Contacts");
		System.out.println("Press 2 to Search for Contacts");
		System.out.println("Press 3 to Operate on Contacts");
		
		int input = scan.nextInt();
		
		if(input==1)
		{
			ph.setData();
			System.out.println(hm);
		}
		else if(input==2)
		{
			System.out.println("Search by Name");
			Scanner scn = new Scanner(System.in);
			String inp=scn.nextLine();
			System.out.println("Press 1 to call");
			System.out.println("Press 2 to message");
			System.out.println("Press 3 to go back to main menu");
			int inp1=scn.nextInt();
			if(inp1==1) {
				System.out.println("Call is connecting");
				System.out.println("End Call");
			}
			else if(inp1==2) {
				System.out.println("Type Message");
				Scanner scn2 = new Scanner(System.in);
				String msg=scn2.nextLine();
				System.out.println("Sending message: "+msg);
			}
			else if(inp1==3)
			{
				System.out.println("Go back to Main Menu");
			}
		}
		else if(input==3) {
			System.out.println("Press 1 to add Contact");
			System.out.println("Press 2 to delete Contact");
			System.out.println("Press 3 to edit Contact");
		}		
	}
	public static void setData()
	{
		PhoneSimulator ph1=new PhoneSimulator();
		
		ph1.setName("Poornima");
		ph1.setNumber(973554558);
		ph1.setGroup("Family");
		
		PhoneSimulator ph2=new PhoneSimulator();
		
		ph2.setName("Inchara");
		ph2.setNumber(979877958);
		ph2.setGroup("Friend");
		
		hm.put("1",ph1);
		hm.put("2",ph2);

	}
}
