package com.dev.phone;

public class Data {

	private String name;
	private long number;
	private String group;

	@Override
	public String toString() {
		return "Data [name=" + name + ", number=" + number + ", group=" + group + "]";
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		name = name;
	}
	public long getNumber() {
		return number;
	}
	public void setNumber(long number) {
		number = number;
	}
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		group = group;
	}

}
